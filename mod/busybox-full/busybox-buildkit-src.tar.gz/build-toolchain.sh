#!/usr/bin/env bash

set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
PFX=mipsel-natywish-linux-gnu
CTNG_VER=1.26.0
WORK="$HERE/_work"
TC="$HERE/toolchain/$PFX"
JOBS="${JOBS:-$(nproc 2>/dev/null || echo 4)}"
CFG="$HERE/ctng/ctng-full.config"

[ -f "$CFG" ] || { echo "NOT FOUND: $CFG"; exit 1; }

mkdir -p "$WORK/tarballs" "$HERE/toolchain"
cd "$WORK"

CTDIR="$WORK/crosstool-ng-$CTNG_VER"

if [ ! -x "$CTDIR/ct-ng" ]; then
  [ -f ct.tar.xz ] || wget -O ct.tar.xz \
      "https://github.com/crosstool-ng/crosstool-ng/releases/download/crosstool-ng-$CTNG_VER/crosstool-ng-$CTNG_VER.tar.xz" \
    || curl -fLo ct.tar.xz "http://crosstool-ng.org/download/crosstool-ng/crosstool-ng-$CTNG_VER.tar.xz"
  
  tar xf ct.tar.xz
  ( cd "$CTDIR" && ./configure --enable-local && make -j"$JOBS" )
fi

cd "$CTDIR"
cp "$CFG" .config
export CT_PREFIX="$HERE/toolchain"

sed -i "s|^CT_PREFIX_DIR=.*|CT_PREFIX_DIR=\"$TC\"|" .config
grep -q '^CT_PREFIX_DIR=' .config || echo "CT_PREFIX_DIR=\"$TC\"" >> .config

if grep -q '^CT_LOCAL_TARBALLS_DIR=' .config; then
  sed -i "s|^CT_LOCAL_TARBALLS_DIR=.*|CT_LOCAL_TARBALLS_DIR=\"$WORK/tarballs\"|" .config
else
  echo "CT_LOCAL_TARBALLS_DIR=\"$WORK/tarballs\"" >> .config
fi

./ct-ng olddefconfig
./ct-ng build

"$TC/bin/$PFX-gcc" --version | head -1