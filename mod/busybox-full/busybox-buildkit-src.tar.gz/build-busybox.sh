#!/usr/bin/env bash

set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
PFX=mipsel-natywish-linux-gnu
TC="${TOOLCHAIN:-$HERE/toolchain/$PFX}"
BINPFX="$TC/bin/$PFX-"
JOBS="${JOBS:-$(nproc 2>/dev/null || echo 4)}"
if [ ! -x "${BINPFX}gcc" ]; then
  echo "!! toolchain not found:${BINPFX}gcc"
  echo "   Run ./build-toolchain.sh;or TOOLCHAIN=/path/to/$PFX ./build-busybox.sh FIRST!!"
  exit 1
fi
cd "$HERE/busybox-src"
[ -f .config ] || { echo "NOT FOUND: busybox-src/.config"; exit 1; }
make CROSS_COMPILE="$BINPFX" -j"$JOBS"
echo "==> Clean output:$PWD/busybox"
md5sum busybox || true
"${BINPFX}readelf" -h busybox | grep -i flags || true
"${BINPFX}readelf" -d busybox | grep NEEDED || true
